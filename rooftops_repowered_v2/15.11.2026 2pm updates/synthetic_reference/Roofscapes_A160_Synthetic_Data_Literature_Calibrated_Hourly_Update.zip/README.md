# Roofscapes (Re)Powered V2 — Synthetic Inputs + Codex EnergyPlus Handover

**Prepared for the A160 office + nearby school / 18 homes / hotel cluster.**

## What is inside?

- `datasets/synthetic/a160_cluster/published_site_facts.csv`: public facts only, with blanks for unknown values and direct source URLs.
- `.../geometry_hypotheses.csv`: 12 low/base/high conditioned-area, glazing and envelope hypotheses (not verified geometry).
- `.../energyplus_scenario_parameters.csv`: 12 low/base/high electric-HVAC, lighting, plug and occupancy starting hypotheses (not manufacturer or meter values).
- `.../weekly_schedule_shapes.csv`: 2,016 normalized hypothetical weekly-hour records.
- `.../hourly_schedule_reference_2017.csv`: 105,120 *schedule fraction* rows for 2017 **local standard time**; not kWh and not UTC-aligned with PVGIS.
- `.../assumption_register.csv`: 156 row-level numerical hypotheses with limitations and public method references.
- `.../source_register.csv`: source URLs and exact claim types.
- `.../weather_alignment_contract.json`: explicit blocked weather/time compatibility.
- `.../geometry_import_plan.json`: Barcelona City 2026 DWG and Rhino 8/Ladybug/Honeybee plan and evidence gaps.
- `.../existing_pv_do_not_overwrite.json`: actual A160 kWp / panel count / measured generation remain unknown.
- `.../participant_eligibility_unverified.csv`: legal/network connections and participant agreements remain **not verified** for all four buildings.
- `.../impact_assumptions_unverified.json`: prices, emissions and cost-sharing fields deliberately null until sourced.
- `.../data_dictionary.json`, `.../manifest.json`: schema roles and SHA-256 input fingerprints.
- `scripts/generate_cluster_inputs.py`: deterministic standalone generator (`python scripts/generate_cluster_inputs.py`).
- `docs/CODEX_STAGED_HANDOVER.md`: detailed development execution plan and scientific gates.
- `CODEX_START_HERE.md`: short prompt to paste into Codex.

## Provenance and scientific limitations

The source URLs establish **building identity, uses, publicly reported areas/schedules, available Rhino and EnergyPlus tools**, not site-specific density, HVAC or occupancy values. Numerical area fractions, thermal parameters, equipment densities and schedules are **synthetic analyst-created sensitivity assumptions**. They are not validated or calibrated and must not be treated as observed electricity consumption. They should be replaced if reliable public architectural/technical sources can provide better evidence. The outputs of EnergyPlus, if actually run, are *simulated reference labels*; they are not real A160 meters.

**Import location inside V2 repo:** copy `datasets/synthetic/a160_cluster/` and `scripts/generate_cluster_inputs.py` to these exact paths. It is intentionally separate from `datasets/processed/`, `config/project.json`, and the verified PV supply path.

**Simulation engine:** Rhino geometry is optional but beneficial; the EnergyPlus electric simulation is required before AI training. If Rhino/city DWG cannot be retrieved, report limitation and fall back to transparent geometric assumptions. Never fabricate evidence.

**Important:** The latest preexisting UI/PVGIS integration and 70 reported tests are not modified by this bundle.


## Update — published-benchmark hourly electricity proxy (15 November 2026)

Added `electricity_benchmarks.csv`, `hourly_electricity_proxy_2017.csv`, `electricity_proxy_validation.csv`, `electricity_proxy_method.md/json`, references R13-R19 and a generator/test. See the method for source-specific evidence and transfer limits. **These new hourly kWh figures are literature-calibrated illustrative estimates, not measured or EnergyPlus loads. They are never ML training/validation labels or cleared sharing inputs.** Original synthetic schedules, physics parameters and published building facts are unchanged. The annual total per building/case is exact by construction, not validation.

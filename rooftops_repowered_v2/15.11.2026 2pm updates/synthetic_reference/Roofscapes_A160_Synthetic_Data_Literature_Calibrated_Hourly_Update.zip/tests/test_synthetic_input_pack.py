"""Stdlib validation for synthetic A160 source inputs; no network/model packages needed."""
from pathlib import Path
from collections import Counter
import csv, hashlib, json, unittest, datetime as dt
R=Path(__file__).resolve().parents[1]/'datasets/synthetic/a160_cluster'

def rows(filename):
 with (R/filename).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))

class TestPack(unittest.TestCase):
 def test_inputs_exist_and_manifest_fingerprints(self):
  manifest=json.loads((R/'manifest.json').read_text())
  for name,info in manifest['input_files'].items():
   data=(R/name).read_bytes()
   self.assertEqual(hashlib.sha256(data).hexdigest(),info['sha256'])
   self.assertEqual(len(data),info['bytes'])
 def test_published_facts_have_unknowns_blank(self):
  rr=rows('published_site_facts.csv');self.assertEqual(len(rr),4)
  self.assertEqual({r['building_id'] for r in rr},{'A160','ITAEB','CDG95_97','NH_POBLENOU'})
  for r in rr:
   self.assertEqual(r['installed_pv_kwp'],'')
   self.assertEqual(r['observed_hourly_electricity_kwh'],'')
   self.assertTrue(r['source_urls'].startswith('https://'))
 def test_housing_area_is_published_unit_subtotal(self):
  rr={r['building_id']:r for r in rows('published_site_facts.csv')}
  self.assertEqual(int(rr['CDG95_97']['published_dwellings_total_m2']),10*45+8*55)
 def test_parameter_coverage_and_assumed_flags(self):
  gg=rows('geometry_hypotheses.csv');pp=rows('energyplus_scenario_parameters.csv')
  self.assertEqual(len(gg),12);self.assertEqual(len(pp),12)
  self.assertEqual({(x['building_id'],x['scenario']) for x in gg},{(x['building_id'],x['scenario']) for x in pp})
  self.assertTrue(all(x['value_origin']=='SYNTHETIC_SENSITIVITY_ASSUMPTION' and x['numeric_values_from_referenced_source']=='false' for x in gg))
  self.assertTrue(all(x['valid_for_energyplus']=='false_until_geometry_weather_and_hvac_qa' for x in pp))
 def test_weekly_normalized_complete(self):
  rr=rows('weekly_schedule_shapes.csv');self.assertEqual(len(rr),4*3*7*24)
  self.assertEqual(len({(x['building_id'],x['scenario'],x['day_of_week_monday_0'],x['hour_local_standard']) for x in rr}),len(rr))
  for x in rr:
   for col in ('occupancy_fraction','lighting_fraction','equipment_fraction','hvac_availability_fraction'):
    self.assertTrue(0<=float(x[col])<=1)
   self.assertEqual(x['actual_usage_verified'],'false')
 def test_hourly_synthetic_not_meter(self):
  rr=rows('hourly_schedule_reference_2017.csv');self.assertEqual(len(rr),4*3*8760)
  grp=Counter((x['building_id'],x['scenario']) for x in rr)
  self.assertEqual(len(grp),12);self.assertTrue(all(v==8760 for v in grp.values()))
  for x in rr:
   self.assertEqual(x['data_origin'],'SYNTHETIC_INPUT_NOT_ELECTRICITY_METER')
   self.assertNotIn('electricity_kwh',x)
  self.assertEqual(rr[0]['timestamp_local_standard'],'2017-01-01 00:00:00')
  self.assertEqual(rr[-1]['timestamp_local_standard'],'2017-12-31 23:00:00')
 def test_weather_and_pv_gates(self):
  weather=json.loads((R/'weather_alignment_contract.json').read_text())
  self.assertFalse(weather['ready_for_shared_electricity_balance'])
  p=json.loads((R/'existing_pv_do_not_overwrite.json').read_text())
  self.assertIsNone(p['installed_capacity_kwp'])
  self.assertIsNone(p['actual_generation_kwh'])
  self.assertFalse(p['may_feed_verified_sharing'])
 def test_geometry_source_not_claimed_downloaded(self):
  p=json.loads((R/'geometry_import_plan.json').read_text())
  self.assertFalse(p['official_primary']['file_downloaded_in_this_handover'])
  self.assertFalse(p['official_primary']['a160_geometry_checked'])
  self.assertFalse(p['rhino_8_support']['rhino_or_lbt_installed_verified_on_user_PC'])

if __name__=='__main__':unittest.main()

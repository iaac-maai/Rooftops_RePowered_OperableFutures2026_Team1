"""Validation for non-training literature-calibrated synthetic electricity fixture."""
import csv, math
from pathlib import Path
from collections import defaultdict
P=Path(__file__).resolve().parents[1]/'datasets/synthetic/a160_cluster'

def rows(name):
    with (P/name).open(newline='',encoding='utf-8') as f:
        yield from csv.DictReader(f)

def test_hourly_proxy_complete_and_ineligible():
    counts=defaultdict(int); totals=defaultdict(float)
    for r in rows('hourly_electricity_proxy_2017.csv'):
        key=r['building_id'],r['scenario'];counts[key]+=1
        value=float(r['hourly_electricity_proxy_kwh']);totals[key]+=value
        assert math.isfinite(value) and value>0
        assert all(r[c]=='false' for c in ('is_measured','is_energyplus_output','has_hourly_weather','training_eligible','independent_validation_eligible','energy_sharing_eligible'))
        assert r['data_origin']=='LITERATURE_CALIBRATED_SYNTHETIC_PROXY_NOT_MEASURED_NOT_ENERGYPLUS'
    assert len(counts)==12 and set(counts.values())=={8760}
    for b in rows('electricity_benchmarks.csv'):
        key=b['building_id'],b['scenario']
        assert abs(totals[key]-float(b['annual_electricity_target_kwh']))<1e-5

def test_research_sources_and_units():
    ids={r['source_id'] for r in rows('source_register.csv')}
    for b in rows('electricity_benchmarks.csv'):
        assert set(b['source_ids'].split('|'))<=ids
        assert b['benchmark_source_urls'].startswith('https://')
        assert b['data_origin'].startswith('LITERATURE_CALIBRATED_SYNTHETIC')

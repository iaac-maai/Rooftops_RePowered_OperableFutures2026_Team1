# Roofscapes (Re)Powered V2 — Codex handover: A160 EnergyPlus → AI training

**Prepared:** 15 November 2026  
**Target repository:** https://github.com/SindhujaDavuluri/rooftops_repowered_v2  
**Verified main at review:** `de3ea0ca5f2c022af5f4d50d054a0c897e5eb914`  
**Input bundle:** `datasets/synthetic/a160_cluster/` plus `scripts/generate_cluster_inputs.py`.  
**Status:** Instructions and synthetic input fixtures prepared; **Codex has not been executed or assigned through this chat**. Start Codex using `CODEX_START_HERE.md` in this bundle.

## 0. Non-negotiable research distinctions

1. Synthetic parameter values are **analyst-selected sensitivity assumptions**. Public sources document building *facts and typologies*, **not** the invented numerical operating values. Every numeric hypothesis appears in `assumption_register.csv` with an explanatory `numerical_evidence=NONE_SITE_SPECIFIC` field and URL to typology/method context. No file is a measured hourly electricity dataset.
2. Do not overwrite `config/project.json`, original reference office model, original `pipeline/models/*.joblib`, locked A160 roof prediction, existing reports, historic tests or private/local datasets. Implement on a new branch.
3. `existing_pv_do_not_overwrite.json` is a **read-only reminder**. Installed kWp, module count, inverter and measured PV generation at A160 remain `null`. The existing PV array is visually confirmed; the 95.34–116.76 kWp *retrospective potential* is not installed plant capacity. PVGIS hypothetical supply remains ineligible for the actual community matching command.
4. The original office EnergyPlus/XGBoost model approximates a **511.1574 m² US reference small office** using Barcelona IWEC, not A160. Its held-out scenario test MAE ~0.648 kWh is against simulated targets only. Expanded A160 AI needs separate geometries, simulations, splits and model artifacts.
5. Do not silently align PVGIS SARAH3 historical **2017, :10 UTC intervals** with IWEC typical-year simulated weather, nor convert standard-time schedules into civil/DST timestamps by simple relabeling. See `weather_alignment_contract.json`. For solar–demand matching require a documented matched weather/calendar setup or label the comparison as a disconnected sensitivity—not as a physically coherent same-weather result.
6. User has requested: **build and validate A160 site-appropriate EnergyPlus demand FIRST; only after it passes the independent simulation QA gate, continue AI model training**. Do not train on generated schedule fractions as if they were measured kWh.

## 1. What is already implemented in `main`

- A160 selected as host, cluster candidates ITAEB, Ciutat de Granada 95–97, NH Barcelona Diagonal Poblenou. Use `datasets/inputs/case_study_candidates.csv`; it is not an approved participant inventory.
- V1-derived A160 rooftop screening under `pipeline/step_02_roof_capacity`, both retrospective and additional roof results. Use `reports/roof_capacity/A160/README.md` for constraints.
- PVGIS 5.3 `seriescalc` API acquisition and explicit hypothetical hourlies under `pipeline/step_03_pvgis` and `reports/pvgis/A160/`. No downloaded PVGIS data is needed for this preparatory A160 geometry milestone; the existing hourly cache may be local-only.
- Functional loopback read-only seven-view UI: `python -m ui.server`, `ui/README.md`, `ui/API.md`. Missing A160 demand and actual sharing remain pending, correctly.
- Prior measured BDG2 experiments failed to beat the primary hour-of-week benchmark. Preserve these negative results.
- Existing EnergyPlus project: `pipeline/step_05_simulation_surrogate/{setup,simulate,train,predict}.py`, `config/simulation.json`, model report. Don't reuse its train/test results as proof of A160 accuracy.
- Verification report `ui/docs/pv-integration/verification.json`: 70 Python tests passed when committed; rerun all tests.

## 2. Rhino 8 + publicly downloadable Barcelona geometry: evaluated as viable

**YES: the architectural geometry route works in principle.**

- Official Barcelona City Council **2026 CAD 3D building model**, downloadable by neighborhood in **DWG 3D** under CC BY 4.0: https://portaldades.ajuntament.barcelona.cat/mapes/146 . Start by selecting **“DWG 3D (el Parc i la Llacuna del Poblenou)”**. Its direct file URL and the fidelity of A160 inside the file have **not yet been verified**; the city's web portal may require a manual download/click. Record filename, download URL, license, date, checksum and coordinate system. Do not assert that the actual A160 as-built geometry was obtained before inspecting it.
- AMB official LoD1 metropolitan 3D alternative (DWG, SKP, GLB): https://geoportalcartografia.amb.cat/AppGeoportalCartografia2/?Categoria=Models3D&Producte=57&locale=es . **LoD1 flattens roof detail** and is for context/massing only.
- Rhino 8 documentation lists DWG and GLB import/export: https://docs.mcneel.com/rhino/8/help/en-us/fileio/_index_of_import_export_file_types.htm .
- **Ladybug Tools 1.10 supports Rhino 6–8** (Windows and Mac): https://discourse.ladybug.tools/t/ladybug-tools-for-grasshopper-1-10-0-release/40026 .
- Honeybee Model → OpenStudio OSM → EnergyPlus IDF and hourly simulation: https://docs.ladybug.tools/hb-energy-primer/components/5_simulate/model_to_osm ; Python CLI also supports HBJSON → OSM: https://www.ladybug.tools/honeybee-energy/docs/cli/translate.html .

**Rhino is a geometry-preparation accelerator, not a prerequisite to continue the reproducible physics workflow.** If Rhino 8/LBT is not installed or cannot be run headlessly, stop at a documented Rhino handoff and implement a documented EnergyPlus/Honeybee geometry fallback from verifiable volumes and zones. Do not create fictitious `.3dm` or `.idf` files and label them sourced from the city.

### Required Rhino geometry QA

- Identify cadastral host `2635601DF3823F` (160 sits in CL ALMOGAVERS 154–164). A160 was completed in 2022. Use the current building, not any earlier parcel geometry.
- Import 2026 neighborhood DWG into Rhino 8 at appropriate units and metric CRS **EPSG:25831**. Save a *localized* model coordinate origin for energy simulation, plus metadata for round-trip to world coordinates; avoid numerically huge coordinates inside EnergyPlus.
- Cross-check municipal massing against published architectural **plans and sections**: https://www.batlleiroig.com/en/projects/oficines-almogavers-160-a-barcelona/ and developer: https://www.conrentramway.com/portfolio/a160/ . Developer reports ground + **five** upper floors and **9,400 m²** office space; architect reports **13,385 m² constructed**; neither establishes actual conditioned floor area. Do not confuse cadastral footprint (~1,718.03 m²) with the upper rooftop usable area.
- Extract closed floors and thermal zones (atrium/courtyard, core, perimeter, glazing, roof and ground conditions); distinguish surrounding shading buildings from energy zones. Inspect areas, volumes, surface normals, intersections, gaps, adjacency, severe aspect ratios, orientations and stair cores. Save QA overlays and a written decision on which details are approximated.
- Export reviewed `A160_georeferenced_massing.3dm`, simulation `A160_thermal_zones.hbjson` and an `idf`/`osm` (if tools available), `geometry_QA_report.json` and a source/drawing list. If any artifact cannot be built, write an honest blocker instead of a blank/fake model.

## 3. Phase A — site-appropriate A160 EnergyPlus simulations (DO THIS FIRST)

**Inputs:** `published_site_facts.csv`, `geometry_hypotheses.csv`, `energyplus_scenario_parameters.csv`, `weekly_schedule_shapes.csv`, `hourly_schedule_reference_2017.csv`, `assumption_register.csv`, public architectural references, reviewed 3D geometry, weather and thermal-system assumptions.

**Implementation:**

1. Run `python -m pytest -q` and `python -m pipeline status` before modifying anything; verify local pinned portable EnergyPlus, Barcelona IWEC and original `.joblib` artifacts. Log missing local binaries without substituting numbers.
2. Copy this *input* package under `datasets/synthetic/a160_cluster/`; add it as new source/configs and tests without modifying earlier results. Check CSV schemas/provenance/hashes.
3. Implement a new dedicated `pipeline/step_05_simulation_surrogate/a160/` or similarly isolated module, **not** a replacement for the small-office route. Model one reviewed A160 geometry and explicit low/base/high sensitivities for unknown conditioned areas, occupancy, equipment, envelope and **electric** HVAC. Note that this pack is illustrative input: EnergyPlus construction classes and templates still require expert implementation and QA.
4. Energy simulation must meter **`Electricity:Facility`**, convert joules to hourly kWh (divide by 3,600,000) and record end uses where available. Thermal ideal-loads demand is **not** electricity. Meter exports should be nonnegative, finite and complete at required hourly resolution.
5. Decide the weather convention before running: Barcelona IWEC typical-year is acceptable for an **internal** EnergyPlus surrogate baseline, but may not be passed off as measured 2017 or a matching PVGIS SARAH3 2017 day-by-day weather. If physically aligned PVGIS comparison is required, source a compatible weather year/EPW with same temporal basis and **hold the join until independently verified**. Timestamp mapping must state hour-start vs hour-end and DST rules.
6. Use a reproducible, configurable sweep with at least 24 distinct **complete** annual operating/configuration runs where computationally feasible, varying schedules, equipment, envelope/HVAC and at least two documented geometry sensitivity variants. If fewer than 24 complete, flag `insufficient_configs` and block supervised model acceptance rather than inventing results. Make the run count adjustable; avoid a full factorial explosion without a run budget. Record parameter hashes and seed 73.
7. Implement smoke test first (1 annual complete run), then full sweep; verify non-NaN/kWh and source/weather configuration. Compare annual kWh/m² of simulated reference with a plausible office benchmark, but never call benchmark agreement local calibration. If meter data are missing, actual A160 prediction accuracy remains unvalidated.

**Outputs required:**

- `config/a160_simulation.json` and `reports/a160_energyplus/input_audit.json` documenting chosen assumptions, geometry variant, engine version, weather year and provenance.
- `datasets/synthetic/energyplus/a160_*/` individual generated and cached IDF, E+ output, manifest/error logs; never fabricate or commit bulky generated binaries.
- `datasets/processed/a160_energyplus_hourly.csv.gz` with `simulation_id`, scenario, `timestamp_local_standard`, `electricity_kwh`, known synthetic schedules/parameters, weather features, `data_origin=SIMULATED_PHYSICS` and input hash.
- `reports/a160_energyplus/quality_report.json`, `model_geometry_report.md`, scenario summary CSV and visual annual/weekday/weekend plots.

**EnergyPlus gate:** Pass one smoke run, planned simulations, hourly coverage, simulation warnings review, sensible end-use/electricity energy balance, reproducibility and independent split feasibility. **If this fails, stop and report what is needed; do not proceed to AI training.**

## 4. Phase B — A160 AI training (AUTO-CONTINUE ONLY AFTER PASS)

**Goal:** Train a distinct XGBoost surrogate to approximate a *site-appropriate synthetic EnergyPlus A160 model*. It remains *simulation-surrogate accuracy*, not real-building accuracy.

1. Use the newly simulated labeled `Electricity:Facility` hourly kWh as the target. Use only data available at inference (geometry/scenario, schedules, weather and calendar). Do not use meter targets or EnergyPlus target-derived values as predictors.
2. Hold out **whole simulation configurations** before feature scaling, feature selection or tuning. If geometries vary, include a disjoint geometry-variant diagnostic/holdout where support permits. Never split random hours from the same run across train and test. Keep train/validation/test IDs and hashes committed.
3. Benchmark **hour-of-week**, schedule-aware linear regression and XGBoost using identical split and data. Report `MAE_kWh`, `RMSE_kWh`, `NMAE_of_mean_load` overall, per scenario, per configuration, peak-vs-nonpeak and weekday/weekend; calculate error for an annualized profile where meaningful.
4. Pass the predeclared quality gate only when XGBoost beats both baselines on validation MAE and unseen held-out test MAE. If it does not, report failure and **recommend the best baseline**; keep XGBoost as experimental.
5. Store separately under `pipeline/models/demand_a160_energyplus_surrogate.joblib` and `reports/a160_surrogate/`. Include model card with archetype/geometry validity, training assumptions, weather, metrics and failures; prevent arbitrary area scaling or transfer to residential, hotel or school profiles.
6. Add a CLI `predict-a160` or suitable isolated route, with domain restrictions. Do not change `predict-office` or the default `config/project.json` until requested/reviewed. Make all UI metrics read-only, labeled `VALIDATED_SIMULATION_DOMAIN` or `UNVERIFIED_REAL_WORLD_TRANSFER`.
7. Run preservation and new tests; provide a complete reproduction command including dependencies/engine versions, input and model hashes.

**Deliverables:** new validated-or-failed model, performance tables, holdout manifests, two diagnostic charts, inference contract, API-ready report, and precise readiness status.

## 5. Phase C — later mixed-use typologies (prepare, don't falsely claim complete)

- Use school (ITAEB), 18 homes at Ciutat de Granada 95–97, and NH Barcelona Diagonal Poblenou in the `published_site_facts.csv` and synthetic scenario files. The first priority is **A160**; later use DOE **school, mid-rise apartment, hotel** prototypes with *Barcelona site* geometry/schedule inputs and separate validation.
- ITAEB published example shifts 08:00–14:10 and 15:00–21:10 apply to particular course years, not all rooms; 2017 term-month placeholder excludes July/Aug only and ignores actual holidays (strictly synthetic).
- Housing 18 dwellings are 10×45m² and 8×55m² = **890 m² published unit-area subtotal**; does not prove conditioned whole-building area, electricity consumption or residents' situations.
- Hotel official site lists **129 rooms on six floors**, but no actual room utilization or HVAC. All occupancy multipliers are synthetic.
- Do not apply a model trained on A160 offices to those uses without independent physics runs and validation. A separate typology baseline is preferable to unsupported transfer.

## 6. Acceptance tests / artifacts for the PR

- [ ] Existing `main` tests remain passing, previous model hashes unchanged, UI seven screens still functional.
- [ ] All synthetic inputs independently reproduce via `python scripts/generate_cluster_inputs.py` and test.
- [ ] DWG source/status, coordinate basis, licensing and survey date recorded; Rhino 8 + Honeybee path tested **where installed** or explicit missing-environment blocker.
- [ ] No site fact silently inferred from the synthetic assumption tables; no fabricated meter, PV kWp or actual model certification.
- [ ] A160 geometry QA, one annual EnergyPlus smoke run, then documented configuration sweep if available.
- [ ] Each output interval is electricity in kWh, not ideal thermal loads.
- [ ] Weather/UTC/DST/EPW mismatch remains explicit; no premature sharing integration.
- [ ] AI training occurs only after simulation QA succeeds and has genuine held-out configuration validation; otherwise report a blocked stage.
- [ ] Model card includes performance vs both baselines, transfer limits, model version and error statistics.
- [ ] At completion, create/update dedicated `reports/a160_energyplus/` and `reports/a160_surrogate/` + `reports/NEXT_STEPS.md`; do not report as-built or real-world measured accuracy.

## 7. Sources

All public source URLs and their *limited claims* are also in `datasets/synthetic/a160_cluster/source_register.csv`. Key official links: A160 architecture/developer; ITAEB curriculum schedule; IMHAB 18 homes; NH hotel; DOE prototype building library; municipal 2026 3D CAD; AMB LoD1; Rhino import; Ladybug/Honeybee; current V2 data contracts. This pack's numerical HVAC/area/occupancy sensitivities were selected for research experiment design, **not** copied from those sources.


## Addendum: literature-based hourly consumption proxies (15 Nov 2026)

The user requested research-grounded hourly electricity estimates. The addon under `datasets/synthetic/a160_cluster/electricity_*` and `hourly_electricity_proxy_2017.csv` supplies illustrative 8760-hour kWh for 4 typologies x low/base/high, derived from annually reported electricity intensity/household/room values. **These proxies are neither simulator labels nor meter data. Never train AI on them, never use them as independent validation, and never bypass the sharing eligibility checks.** Compare EnergyPlus annual EUI and hourly shape against these rough references only after independent simulation. Use `electricity_proxy_method.md`, `electricity_benchmarks.csv` and `source_register.csv` for source links and explicit carrier boundaries.

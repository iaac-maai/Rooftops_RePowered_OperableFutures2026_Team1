"""Optional human-readable input workbook; CSV and JSON are the authoritative machine inputs."""
import csv
from pathlib import Path
from artifact_tool import Workbook, SpreadsheetFile
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'datasets/synthetic/a160_cluster'
wb=Workbook.create()
for sheetname, filename in [('Building Facts','published_site_facts.csv'),('Geometry Cases','geometry_hypotheses.csv'),('EnergyPlus Inputs','energyplus_scenario_parameters.csv'),('Source Register','source_register.csv')]:
    with (DATA/filename).open(encoding='utf-8',newline='') as file:
        values=list(csv.reader(file))
    sheet=wb.worksheets.add(sheetname)
    # Empty strings are preserved; numbers kept as text in this source-led review workbook.
    h=len(values[0]);last=chr(ord('A')+h-1) if h<=26 else None
    sheet.get_range_by_indexes(0,0,len(values),h).values=values
    hdr=sheet.get_range_by_indexes(0,0,1,h)
    hdr.format={'fill':'#174C3C','font':{'bold':True,'color':'#FFFFFF'},'row_height':32,'wrap_text':True}
    sheet.freeze_panes.freeze_rows(1)
    sheet.get_range_by_indexes(1,0,max(1,len(values)-1),h).format.row_height=30
    # column widths bounded because long URLs should be readable by selection, not widen table to full URL length
    sheet.get_range_by_indexes(0,0,len(values),h).format.column_width=22
    for j, title in enumerate(values[0]):
        if any(word in title for word in ('source_url','source_urls','fact_limitations','derivation','reference_archetype','what_source_actually_supports')):
            sheet.get_range_by_indexes(0,j,len(values),1).format.column_width=35
        if title in ('building_id','scenario','building_use'):
            sheet.get_range_by_indexes(0,j,len(values),1).format.column_width=16
    sheet.get_range_by_indexes(1,0,max(1,len(values)-1),h).format.wrap_text=True
    sheet.get_range_by_indexes(0,0,1,h).format.vertical_alignment='center'
summary=wb.worksheets.add('Read Me')
readme=[
 ['ROOFSCAPES V2 — SYNTHETIC ENERGYPLUS INPUTS',''],
 ['PURPOSE','Human review of exported CSVs; the machine inputs are in datasets/synthetic/a160_cluster/'],
 ['INPUT SCOPE','A160 offices, ITAEB school, 18 municipal homes, NH Barcelona Diagonal Poblenou'],
 ['DOCUMENTED FACTS','Some building dimensions, uses, school course times and hotel rooms; sources in Source Register'],
 ['SYNTHETIC VALUES','Geometry fractions, conditioned areas, wall U-values, WWR, equipment, HVAC COPs and schedules are analyst assumptions'],
 ['NO OBSERVED DEMAND','No measured electricity time series is available; generate kWh with EnergyPlus only after geometry/weather QA'],
 ['NO VERIFIED PV CAPACITY','Existing A160 array confirmed visually, but installed kWp/module count remain unknown'],
 ['TIME BASIS','Synthetic local standard-time 2017 schedule; NOT UTC and NOT aligned to PVGIS 2017 SARAH3'],
 ['MODELING GATE','Run EnergyPlus electricity meter with full QA before AI training; no ideal-load substitution'],
 ['OPEN DATA','Barcelona 2026 DWG by neighborhood: https://portaldades.ajuntament.barcelona.cat/mapes/146'],
 ['HONEYBEE','https://docs.ladybug.tools/hb-energy-primer/components/5_simulate/model_to_osm'],
 ['MODEL SOURCES','https://www.energycodes.gov/prototype-building-models'],
 ['REPOSITORY','https://github.com/SindhujaDavuluri/rooftops_repowered_v2'],
]
summary.get_range_by_indexes(0,0,len(readme),2).values=readme
summary.get_range('A1:B1').format={'fill':'#174C3C','font':{'color':'#FFFFFF','bold':True},'row_height':32}
summary.get_range('A1:A13').format.column_width=30
summary.get_range('B1:B13').format.column_width=90
summary.get_range('A2:B13').format.row_height=36
summary.get_range('B2:B13').format.wrap_text=True
out=ROOT/'Roofscapes_A160_Synthetic_Assumption_Review.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(out))
print(out)
print(wb.inspect({'kind':'table','range':'Read Me!A1:B5','include':'values','table_max_rows':5,'table_max_cols':2}).ndjson[:950])

#!/usr/bin/env python3
"""Deterministic synthetic building-use inputs for Roofscapes V2 (stdlib only).

This generator creates model INPUT assumptions and normalized schedules, NOT energy
simulations or metered observations. Never write into datasets/processed or the
case-study PV/energy-sharing intake paths. No network, Rhino, or EnergyPlus required.
"""
from __future__ import annotations
import csv, datetime as dt, hashlib, json, pathlib
from collections import Counter

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / 'datasets/synthetic/a160_cluster'
OUT.mkdir(parents=True, exist_ok=True)

URLS = {
  'a160_arch': 'https://www.batlleiroig.com/en/projects/oficines-almogavers-160-a-barcelona/',
  'a160_dev': 'https://www.conrentramway.com/portfolio/a160/',
  'a160_cadastre': 'https://ovc.catastro.meh.es/OVCServWeb/OVCWcfCallejero/COVCCallejero.svc/json/Consulta_DNPRC?Provincia=BARCELONA&Municipio=BARCELONA&RefCat=2635601DF3823F',
  'roof_report': 'https://github.com/SindhujaDavuluri/rooftops_repowered_v2/blob/main/reports/roof_capacity/A160/README.md',
  'school': 'https://agora.xtec.cat/ins-itaeb/estudis/cfgs-produccio-daudiovisuals-i-espectacles/',
  'housing': 'https://www.consorcihabitatge.barcelona/es/noticias/el-imhab-entrega-las-llaves-de-18-pisos-de-alquiler-social-en-el-barrio-del-parc-i-la-llacuna-del-poblenou-1405102',
  'hotel': 'https://www.nh-hotels.com/en/hotel/nh-barcelona-diagonal-poblenou',
  'doe': 'https://www.energycodes.gov/prototype-building-models',
  'lbt': 'https://discourse.ladybug.tools/t/ladybug-tools-for-grasshopper-1-10-0-release/40026',
  'honeybee': 'https://docs.ladybug.tools/hb-energy-primer/components/5_simulate/model_to_osm',
  'rhino': 'https://docs.mcneel.com/rhino/8/help/en-us/fileio/_index_of_import_export_file_types.htm',
  'city_3d': 'https://portaldades.ajuntament.barcelona.cat/mapes/146',
  'amb_3d': 'https://geoportalcartografia.amb.cat/AppGeoportalCartografia2/?Categoria=Models3D&Producte=57&locale=es',
  'pvgis': 'https://joint-research-centre.ec.europa.eu/photovoltaic-geographical-information-system-pvgis/using-pvgis-5/api-non-interactive-service_en',
  'repo_docs': 'https://github.com/SindhujaDavuluri/rooftops_repowered_v2/blob/main/docs/DATA_CONTRACTS.md',
}

def write_csv(name, rows, header):
    path=OUT/name
    with path.open('w', encoding='utf-8', newline='') as f:
        writer=csv.DictWriter(f,fieldnames=header,extrasaction='raise')
        writer.writeheader();writer.writerows(rows)
    return path

def write_json(name, data):
    p=OUT/name;p.write_text(json.dumps(data,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8');return p

# Actual published facts only. If a source provides no number, leave blank.
facts = [
 {'building_id':'A160','building_name':'A160 offices','address':'Carrer dels Almogàvers 160, Barcelona, Spain','building_use':'Office','is_host':'true','year_built':'2022','gross_built_area_m2':'13385','published_office_area_m2':'9400','published_floor_count':'6','published_dwelling_count':'','published_room_count':'','published_dwellings_total_m2':'','cadastral_footprint_m2':'1718.03','cadastral_reference':'2635601DF3823F','latitude':'41.399077786613745','longitude':'2.1932134113514765','installed_pv_kwp':'','observed_hourly_electricity_kwh':'','source_urls':URLS['a160_arch']+' | '+URLS['a160_dev']+' | '+URLS['roof_report'],'fact_limitations':'Office/constructed area not conditioned area; footprint not roof area; module count and installed kWp unknown'},
 {'building_id':'ITAEB','building_name':'ITAEB','address':'Carrer dels Almogàvers 131, Barcelona, Spain','building_use':'Education','is_host':'false','year_built':'','gross_built_area_m2':'','published_office_area_m2':'','published_floor_count':'','published_dwelling_count':'','published_room_count':'','published_dwellings_total_m2':'','cadastral_footprint_m2':'','cadastral_reference':'','latitude':'','longitude':'','installed_pv_kwp':'','observed_hourly_electricity_kwh':'','source_urls':URLS['school'],'fact_limitations':'Published 08:00-14:10 / 15:00-21:10 shifts apply to specific courses, not actual whole-building occupancy; adapted building geometry unverified'},
 {'building_id':'CDG95_97','building_name':'Municipal rental housing','address':'Carrer de la Ciutat de Granada 95-97, Barcelona, Spain','building_use':'Residential','is_host':'false','year_built':'2024','gross_built_area_m2':'','published_office_area_m2':'','published_floor_count':'stepped ground+3 and ground+5','published_dwelling_count':'18','published_room_count':'','published_dwellings_total_m2':'890','cadastral_footprint_m2':'','cadastral_reference':'','latitude':'','longitude':'','installed_pv_kwp':'','observed_hourly_electricity_kwh':'','source_urls':URLS['housing'],'fact_limitations':'890 m2 = 10 x 45 + 8 x 55 stated dwelling areas, excludes common services; true conditioned area and any common-service PV unverified'},
 {'building_id':'NH_POBLENOU','building_name':'NH Barcelona Diagonal Poblenou','address':'Carrer d\'Àlaba 94-96, Barcelona, Spain','building_use':'Hospitality','is_host':'false','year_built':'','gross_built_area_m2':'','published_office_area_m2':'','published_floor_count':'6','published_dwelling_count':'','published_room_count':'129','published_dwellings_total_m2':'','cadastral_footprint_m2':'','cadastral_reference':'','latitude':'','longitude':'','installed_pv_kwp':'','observed_hourly_electricity_kwh':'','source_urls':URLS['hotel'],'fact_limitations':'Room count/floors are published, but floor area, room occupancy, HVAC and meter readings not verified'},
]
write_csv('published_site_facts.csv',facts,list(facts[0]))

# All geometric hypotheses are placeholders, not automatically treated as actual.
area_choices={
 'A160':[('low',6580,'70% of 9400 m2 office area'),('base',7520,'80% of 9400 m2 office area'),('high',8460,'90% of 9400 m2 office area')],
 'ITAEB':[('low',1500,'Illustrative institutional gross-to-conditioned area'),('base',2500,'Illustrative institutional gross-to-conditioned area'),('high',3500,'Illustrative institutional gross-to-conditioned area')],
 'CDG95_97':[('low',890,'Stated dwelling area subtotal only; not necessarily conditioned'),('base',980,'890 m2 stated dwelling area + hypothetical common/service area'),('high',1100,'890 m2 stated dwelling area + hypothetical common/service area')],
 'NH_POBLENOU':[('low',3225,'129 rooms times assumed 25 m2/room equivalent'),('base',4515,'129 rooms times assumed 35 m2/room equivalent'),('high',5805,'129 rooms times assumed 45 m2/room equivalent')],
}
source_by_id={'A160':URLS['a160_dev'],'ITAEB':URLS['school'],'CDG95_97':URLS['housing'],'NH_POBLENOU':URLS['hotel']}
geo=[]
for b,choices in area_choices.items():
 for label,area,formula in choices:
  f=next(x for x in facts if x['building_id']==b)
  geo.append({'building_id':b,'scenario':label,'assumed_conditioned_area_m2':area,'assumed_avg_zone_height_m':{'low':3.1,'base':3.5,'high':3.9}[label],
  'assumed_window_to_wall_ratio':{'low':0.30,'base':0.42,'high':0.55}[label],
  'assumed_wall_u_w_m2k':{'low':0.35,'base':0.50,'high':0.75}[label],
  'assumed_roof_u_w_m2k':{'low':0.25,'base':0.35,'high':0.50}[label],
  'assumed_infiltration_ach':{'low':0.25,'base':0.40,'high':0.60}[label],
  'published_floor_count_or_massing':f['published_floor_count'],'geometry_source_status':'PUBLIC_MASSING_ONLY_NOT_ENERGYPLUS_READY',
  'value_origin':'SYNTHETIC_SENSITIVITY_ASSUMPTION','numeric_values_from_referenced_source':'false',
  'derivation':formula,'source_url':source_by_id[b]+' | '+URLS['doe'],
  'review_gate':'VERIFY_2026_CITY_3D_MASSING_THEN_RHINO_THERMAL_GEOMETRY_BEFORE_SITE_CLAIMS'})
write_csv('geometry_hypotheses.csv',geo,list(geo[0]))

# Synthetic electric-system settings. Office equipment levels include values from prior V2 experiment,
# but everything new (density / WWR / COP / occupancy) is assumption, not a measured site value.
params=[]
base={
 'A160': {'people':0.065,'plug':10,'lighting':8,'vent':8,'type':'DOE medium/large office seed; Barcelona site adaptation required'},
 'ITAEB': {'people':0.10,'plug':12,'lighting':9,'vent':10,'type':'DOE school prototype adapted to workshop / audiovisual teaching'},
 'CDG95_97': {'people':0.030,'plug':6,'lighting':5,'vent':6,'type':'DOE mid-rise apartment prototype plus 18 documented units'},
 'NH_POBLENOU': {'people':0.035,'plug':9,'lighting':7,'vent':8,'type':'DOE small hotel prototype; 129 rooms documented'},
}
for b,v in base.items():
 for label,scale in [('low',0.75),('base',1.0),('high',1.3)]:
  area=next(x['assumed_conditioned_area_m2'] for x in geo if x['building_id']==b and x['scenario']==label)
  params.append({'building_id':b,'scenario':label,'conditioned_area_m2':area,
   'peak_people_per_m2_assumed':round(v['people']*scale,5),
   'peak_equipment_w_per_m2_assumed':round(v['plug']*scale,3),
   'peak_lighting_w_per_m2_assumed':round(v['lighting']*scale,3),
   'outdoor_air_l_per_s_per_person_assumed':v['vent'],
   'heating_setpoint_c_assumed':20,'cooling_setpoint_c_assumed':26,
   'heating_cop_assumed':round(3.1/scale,2),'cooling_cop_assumed':round(3.7/scale,2),
   'hvac_assumed_system':'ELECTRIC_HEAT_PUMP_HYPOTHESIS_NOT_VERIFIED',
   'weather_epw_path':'','epw_weather_basis':'PENDING_SOURCE_AND_CALENDAR_ALIGNMENT',
   'calendar_basis':'2017_RESEARCH_REFERENCE_LOCAL_STANDARD_NO_DST',
   'electricity_target':'EnergyPlus Electricity:Facility [J](Hourly) / 3600000',
   'valid_for_energyplus':'false_until_geometry_weather_and_hvac_qa',
   'value_origin':'SYNTHETIC_SENSITIVITY_ASSUMPTION',
   'numeric_values_from_referenced_source':'false','reference_archetype':v['type'],
   'source_urls':URLS['doe']+' | '+source_by_id[b]})
write_csv('energyplus_scenario_parameters.csv',params,list(params[0]))

# Weekly shapes: 0-1 operational fractions, not meters or annual kWh.
# Every scheduled hour is local STANDARD clock in research calendar, not verified actual usage.
def shape_for(b, hour, dow, scenario, month):
  wk=dow<5
  if b=='A160':
    active=wk and 8<=hour<19
    occ=(0.95 if 9<=hour<17 else 0.5 if active else 0.04 if wk else 0.015)
    equipment=0.15+0.85*occ
    lights=0.04+0.96*(0.85 if 8<=hour<19 and wk else 0.05)
    hvac=1.0 if wk and 7<=hour<20 else 0.1
  elif b=='ITAEB':
    # Simplified 2017 reference academic months; does not model real holidays.
    term=month not in (7,8)
    a=wk and term and 8<=hour<15
    e=wk and term and 15<=hour<22
    occ=(0.70 if a else 0.52 if e else 0.02)
    equipment=0.12+0.88*(0.85 if a else 0.9 if e else 0.02)
    lights=0.05+0.95*(0.9 if a or e else 0.02)
    hvac=1.0 if (a or e) else 0.06
  elif b=='CDG95_97':
    occ=0.75 if hour>=19 or hour<7 else 0.55 if (7<=hour<9 or 17<=hour<19) else 0.38 if wk else 0.53
    equipment=0.20+0.80*(0.85 if 19<=hour<23 else 0.65 if 7<=hour<9 else 0.45)
    lights=0.03+0.97*(0.82 if 19<=hour<23 else 0.18 if 6<=hour<8 else 0.04)
    hvac=0.75 if 6<=hour<23 else 0.45
  else:
    occ=0.8 if hour>=21 or hour<8 else 0.5 if 8<=hour<15 else 0.65
    equipment=0.25+0.75*(0.75 if 6<=hour<23 else 0.55)
    lights=0.08+0.92*(0.68 if hour>=18 or hour<7 else 0.4)
    hvac=0.85
  scale={'low':0.75,'base':1.0,'high':1.20}[scenario]
  # preserve nonzero background in every case; upper bound never >1.
  return [round(min(1, max(0,v*scale)),3) for v in (occ,lights,equipment,hvac)]

weekly=[]
for b in base:
 for scenario in ('low','base','high'):
  for dow in range(7):
   for h in range(24):
    o,l,e,v=shape_for(b,h,dow,scenario,3)
    weekly.append({'building_id':b,'scenario':scenario,'day_of_week_monday_0':dow,'hour_local_standard':h,
    'occupancy_fraction':o,'lighting_fraction':l,'equipment_fraction':e,'hvac_availability_fraction':v,
    'schedule_origin':'SYNTHETIC_SCHEDULE','source_url':source_by_id[b]+' | '+URLS['doe'],
    'actual_usage_verified':'false'})
write_csv('weekly_schedule_shapes.csv',weekly,list(weekly[0]))

# Full 8760-hour schedule, 2017 synthetic no-DST clock; not UTC / not PVGIS-aligned.
annual=[]
start=dt.datetime(2017,1,1)
for b in base:
 for scenario in ('low','base','high'):
  for i in range(8760):
   ts=start+dt.timedelta(hours=i)
   o,l,e,v=shape_for(b,ts.hour,ts.weekday(),scenario,ts.month)
   annual.append({'building_id':b,'scenario':scenario,'timestamp_local_standard':ts.strftime('%Y-%m-%d %H:%M:%S'),
    'calendar_convention':'2017_SYNTHETIC_LOCAL_STANDARD_NO_DST',
    'occupancy_fraction':o,'lighting_fraction':l,'equipment_fraction':e,'hvac_availability_fraction':v,
    'is_modelled_school_term': 'unknown' if b!='ITAEB' else ('true' if ts.month not in (7,8) else 'false'),
    'schedule_origin':'SYNTHETIC_SCHEDULE','data_origin':'SYNTHETIC_INPUT_NOT_ELECTRICITY_METER'})
write_csv('hourly_schedule_reference_2017.csv',annual,list(annual[0]))

references=[
 ('R01','A160 built area / date','published_site_facts.csv','A160 13,385 m² constructed; completed 2022','PUBLISHED_SITE_FACT',URLS['a160_arch']),
 ('R02','A160 office area and levels','published_site_facts.csv','9,400 m² size; ground + five floors; not conditioned area','PUBLISHED_SITE_FACT',URLS['a160_dev']),
 ('R03','A160 cadastral and roof milestone','published_site_facts.csv','Existing PV observed; footprint approx. 1,718 m²; kWp unknown','PUBLIC_REPO_RESULT',URLS['roof_report']),
 ('R04','ITAEB course timetable','published_site_facts.csv;weekly_schedule_shapes.csv','One course: 08:00–14:10 and 15:00–21:10; not whole school','PUBLISHED_SITE_FACT_AND_SCHEDULE_SEED',URLS['school']),
 ('R05','Housing composition','published_site_facts.csv;geometry_hypotheses.csv','18 flats = 10 × 45 m² + 8 × 55 m² = 890 m² stated dwelling area','PUBLISHED_SITE_FACT_AND_DERIVED_ARITHMETIC',URLS['housing']),
 ('R06','Hotel room count and floors','published_site_facts.csv;geometry_hypotheses.csv','129 rooms, six floors; room area hypothetical','PUBLISHED_SITE_FACT',URLS['hotel']),
 ('R07','DOE prototype typologies','energyplus_scenario_parameters.csv','Small/medium office; schools; mid-rise apartments; hotels as modeling archetypes','METHOD_REFERENCE_NOT_SITE_CALIBRATION',URLS['doe']),
 ('R08','Rhino 8 + Honeybee compatibility','geometry_hypotheses.csv','Supported LBT 1.10 and OpenStudio/IDF export path','WORKFLOW_REFERENCE',URLS['lbt']),
 ('R09','Open city 3D massing','geometry_hypotheses.csv','Official 2026 DWG 3D by neighborhood; exact A160 representation not audited','GEOMETRY_CANDIDATE_NOT_VALIDATED',URLS['city_3d']),
 ('R10','AMB 3D alternative','geometry_hypotheses.csv','LoD1 geometry; DWG/GLB/SKP available; flat roofs by definition','GEOMETRY_CANDIDATE_NOT_VALIDATED',URLS['amb_3d']),
 ('R11','Current V2 data contract','all synthetic files','Do not overwrite measured/model outputs, and preserve generation-role gates','REPO_CONSTRAINT',URLS['repo_docs']),
 ('R12','PVGIS acquisition','weather_alignment_contract.json','2017 SARAH3 PVGIS synthetic output and minute offsets, not IWEC weather','REPO_METHOD_REFERENCE',URLS['pvgis']),
]
write_csv('source_register.csv',[dict(source_id=a,topic=b,applies_to=c,what_source_actually_supports=d,evidence_type=e,source_url=f) for a,b,c,d,e,f in references],['source_id','topic','applies_to','what_source_actually_supports','evidence_type','source_url'])

assumption_rows=[]
for row in geo:
 for field in ('assumed_conditioned_area_m2','assumed_avg_zone_height_m','assumed_window_to_wall_ratio','assumed_wall_u_w_m2k','assumed_roof_u_w_m2k','assumed_infiltration_ach'):
  assumption_rows.append({'building_id':row['building_id'],'scenario':row['scenario'],'parameter':field,
   'assumed_value':row[field],'unit':{'assumed_conditioned_area_m2':'m2','assumed_avg_zone_height_m':'m','assumed_window_to_wall_ratio':'fraction','assumed_wall_u_w_m2k':'W/m2K','assumed_roof_u_w_m2k':'W/m2K','assumed_infiltration_ach':'1/h'}[field],
   'numerical_evidence':'NONE_SITE_SPECIFIC','assumption_origin':'ANALYST_CREATED_SENSITIVITY','basis_source_url':row['source_url'],
   'validation_action':'REPLACE_WITH_REVIEWED_GEOMETRY_OR_ENVELOPE_RECORD','used_as_observation':'false'})
for row in params:
 for field,unit in [('peak_people_per_m2_assumed','people/m2'),('peak_equipment_w_per_m2_assumed','W/m2'),('peak_lighting_w_per_m2_assumed','W/m2'),('heating_setpoint_c_assumed','degC'),('cooling_setpoint_c_assumed','degC'),('heating_cop_assumed','COP'),('cooling_cop_assumed','COP')]:
  assumption_rows.append({'building_id':row['building_id'],'scenario':row['scenario'],'parameter':field,'assumed_value':row[field],'unit':unit,
    'numerical_evidence':'NONE_SITE_SPECIFIC','assumption_origin':'ANALYST_CREATED_SENSITIVITY','basis_source_url':row['source_urls'],
    'validation_action':'REPLACE_WITH_VERIFIED_OPERATION_HVAC_REFERENCE_IF_AVAILABLE','used_as_observation':'false'})
write_csv('assumption_register.csv',assumption_rows,list(assumption_rows[0]))

write_json('weather_alignment_contract.json', {
 'status':'BLOCKED_UNTIL_WEATHER_COMMON_BASIS_APPROVED',
 'reference_schedule_year':2017,
 'reference_schedule_time_basis':'LOCAL_STANDARD_NO_DST_NOT_UTC',
 'existing_v2_office_simulation_weather':'BARCELONA_IWEC_TYPICAL_YEAR_NOT_OBSERVED_2017',
 'existing_hypothetical_pvgis_weather':'PVGIS_5.3_SARAH3_2017_AT_UTC_MINUTE_10',
 'time_alignment_rule':'Do NOT relabel IWEC to actual 2017 or floor PVGIS :10 silently. New matching exercise requires weather, interval, calendar and daylight-saving policy recorded and independently reviewed.',
 'acceptable_next_actions':['Acquire matching, legally usable hourly 2017 weather variables and construct audited EPW if feasible','If no meteorological consistency possible, report weather mismatch and keep exploratory results separate'],
 'ready_for_shared_electricity_balance':False,
 'source_url':'https://github.com/SindhujaDavuluri/rooftops_repowered_v2/blob/main/pipeline/step_03_pvgis/README.md'
})
write_json('existing_pv_do_not_overwrite.json',{
 'building_id':'A160','status':'PV_ARRAYS_CONFIRMED_VISUALLY_SPECIFICATIONS_UNKNOWN',
 'installed_capacity_kwp':None,'module_count':None,'module_wp':None,'tilt_degrees':None,'azimuth_degrees_from_north':None,
 'actual_generation_kwh':None,'observed_meter_hourly':None,
 'may_feed_verified_sharing':False,'separate_hypothetical_pvgis':True,
 'source_url':URLS['roof_report'], 'rule':'NEVER promote retrospective roof potential to existing plant installed kWp.'})
write_json('geometry_import_plan.json',{
 'goal':'Import current 2026 Barcelona 3D municipal massing as Rhino 8 base; prepare Honeybee thermal-zone geometry separately',
 'official_primary':{'url':URLS['city_3d'],'neighborhood_download_label':'DWG 3D (el Parc i la Llacuna del Poblenou)','dataset_date':'2026-05-26','license':'CC BY 4.0','direct_download_url_verified':False,'file_downloaded_in_this_handover':False,'a160_geometry_checked':False},
 'alternate_amb':{'url':URLS['amb_3d'],'formats':['DWG','SKP','GLB'],'lod':'LoD1, flat roof simplification','site_geometry_checked':False},
 'rhino_8_support':{'dwg_import_supported':True,'honeybee_lbt_1_10_compatible':True,'energyplus_via_openstudio_supported':True,'rhino_or_lbt_installed_verified_on_user_PC':False,'sources':[URLS['rhino'],URLS['lbt'],URLS['honeybee']]},
 'site_a160':{'cadastral_reference':'2635601DF3823F','base_latitude':41.399077786613745,'base_longitude':2.1932134113514765,'preferred_metric_crs':'EPSG:25831','unit':'m',
              'footprint_area_m2_context_only':1718.03,'must_check':['survey timestamp','dwg unit scale','coordinate CRS and origin','correct cadastral building identity','building floors','roof tiers','glazing vs actual facade','closed thermal solids','intersecting room surfaces','adjacent building shading']},
 'required_exports':['source_DWG_reference_info.json','A160_georeferenced_massing.3dm','A160_thermal_zones.hbjson','A160_energyplus_model.idf','geometry_QA_report.json'],
 'warning':'Public LoD1/DWG massing cannot establish as-built interior geometry, panel count, HVAC, occupancy, or energy calibration.'})
# Missing electrical-connection/participation evidence must stay visibly unresolved.
legal_source='https://www.boe.es/eli/es/rd/2019/04/05/244/con'
eligibility=[]
for f in facts:
  eligibility.append({'building_id':f['building_id'],'proposed_role':'host' if f['is_host']=='true' else 'consumer',
    'electrical_connection_id':'','distribution_network_proximity_verified':'false',
    'participation_agreement_exists':'unknown','hourly_coefficient_agreement_exists':'unknown',
    'legal_eligibility':'NOT_VERIFIED','distance_or_network_study_status':'NOT_CHECKED',
    'evidence_status':'PUBLIC_ADDRESS_ONLY_NO_METER_OR_AGREEMENT',
    'source_url':legal_source+' | '+f['source_urls'].split(' | ')[0],
    'use_allowed':'HYPOTHETICAL_SCENARIO_ONLY',
    'conclusion':'No legal or connection eligibility assertion permitted'})
write_csv('participant_eligibility_unverified.csv',eligibility,list(eligibility[0]))
write_json('impact_assumptions_unverified.json',{
 'grid_price_eur_per_kwh':None,'export_price_eur_per_kwh':None,
 'grid_emissions_kgco2e_per_kwh':None,'capex_eur':None,'annual_om_eur':None,
 'benefit_allocation_method':None,'status':'PENDING_SOURCED_ASSUMPTIONS',
 'note':'Do not invent financial/emissions numbers or assert site tariff contracts. This is a placeholder only.',
 'source_url':legal_source})
write_json('data_dictionary.json',{
 'package_role':'INPUTS_FOR_ENERGYPLUS_AND_AI_PLANNING_ONLY','data_origin':'SYNTHETIC_SCENARIO_ASSUMPTIONS_PLUS_PUBLISHED_ANCHORS',
 'file_roles':{
   'published_site_facts.csv':'Only published site facts and documented repo references; blank fields are unknown',
   'geometry_hypotheses.csv':'Low/base/high conditioned-area, envelope and zone-height placeholders; not as-built',
   'energyplus_scenario_parameters.csv':'Low/base/high loads/HVAC hypotheses for EnergyPlus; not yet an executable HVAC/IDF configuration',
   'weekly_schedule_shapes.csv':'2016 normalized weekly schedule rows, March archetypal week, schedule input only',
   'hourly_schedule_reference_2017.csv':'105120 synthetic hourly normalized schedules, local-standard 2017, no energy or UTC claims',
   'assumption_register.csv':'Parameter-level numerical assumptions and relevant method references',
   'source_register.csv':'URLs and precise distinction between site fact and generic method source',
   'weather_alignment_contract.json':'Blocker requiring consistent meteorology/calendar before solar matching',
   'geometry_import_plan.json':'Rhino 8/City 3D download plan and unverified direct DWG status',
   'existing_pv_do_not_overwrite.json':'Null actual existing PV; no speculative escalation to verified sharing',
   'participant_eligibility_unverified.csv':'All sites have unverified electrical connections, participation/coefficients and legal eligibility',
   'impact_assumptions_unverified.json':'Null emissions/economic factors pending dated official sources'},
 'schema_policy':'Never overwrite official V2 config/project.json, validated models, reports, or datasets/processed. Codex must build separate adapters and preserve source hashes.'})
manifest={'package_version':'2026-11-15.a160-synthetic-inputs-v1','created_date':'2026-11-15','repository_target':'SindhujaDavuluri/rooftops_repowered_v2',
 'repo_base_sha_at_review':'de3ea0ca5f2c022af5f4d50d054a0c897e5eb914',
 'source_status':'OFFICIAL_PUBLISHED_FACTS_AND_EXPLICIT_SYNTHETIC_ASSUMPTIONS',
 'has_observed_hourly_load':False,'has_observed_pv_generation':False,'run_energyplus_completed':False,'rhino_model_downloaded':False,
 'allowed_use':'Scoping, geometry QA, EnergyPlus scenario inputs, test fixture design',
 'forbidden_use':'Claiming measured performance or feeding existing verified supply / community match as observed reality',
 'input_files':{},'rows':{'published_site_facts':len(facts),'geometry_hypotheses':len(geo),'energyplus_scenario_parameters':len(params),'weekly_schedule_shapes':len(weekly),'hourly_schedule_reference_2017':len(annual),'assumption_register':len(assumption_rows)}}
for p in sorted(OUT.iterdir()):
 if p.name=='manifest.json':continue
 if p.is_file():manifest['input_files'][p.name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
write_json('manifest.json',manifest)
print(json.dumps({'out':str(OUT),'files':len(list(OUT.iterdir())),'rows':manifest['rows']},indent=2))

"""Regenerate literature-calibrated synthetic hourly kWh proxies; no observed or physics labels.

Use the frozen annual benchmark CSV and original 2017 synthetic schedules.
No network, no pandas and no model inference.
"""
import csv, json, math
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'datasets/synthetic/a160_cluster'

def reader(path):
    with path.open(encoding='utf-8', newline='') as f:
        yield from csv.DictReader(f)

def run():
    params=json.loads((P/'electricity_proxy_method.json').read_text(encoding='utf-8'))
    coeffs=params['weights']
    targets={(r['building_id'],r['scenario']):r for r in reader(P/'electricity_benchmarks.csv')}
    sums=defaultdict(float); counts=defaultdict(int)
    for r in reader(P/'hourly_schedule_reference_2017.csv'):
        key=(r['building_id'],r['scenario']);c=coeffs[key[0]]
        val=c['standby']+sum(c[k]*float(r[k]) for k in ('occupancy_fraction','lighting_fraction','equipment_fraction','hvac_availability_fraction'))
        assert math.isfinite(val) and val>0
        sums[key]+=val; counts[key]+=1
    assert set(counts)==set(targets) and set(counts.values())=={8760}
    out=P/'hourly_electricity_proxy_2017.csv'
    fields=['building_id','scenario','timestamp_local_standard','hour_interval_h','hourly_electricity_proxy_kwh','average_proxy_kw','annual_target_kwh','hourly_weight','annual_normalization_sum','benchmark_source_ids','profile_method','data_origin','is_measured','is_energyplus_output','has_hourly_weather','training_eligible','independent_validation_eligible','energy_sharing_eligible','calendar_convention']
    with out.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in reader(P/'hourly_schedule_reference_2017.csv'):
            key=(r['building_id'],r['scenario']);c=coeffs[key[0]]
            weight=c['standby']+sum(c[k]*float(r[k]) for k in ('occupancy_fraction','lighting_fraction','equipment_fraction','hvac_availability_fraction'))
            annual=float(targets[key]['annual_electricity_target_kwh']);value=annual*weight/sums[key]
            w.writerow({'building_id':key[0],'scenario':key[1],'timestamp_local_standard':r['timestamp_local_standard'],
               'hour_interval_h':'1','hourly_electricity_proxy_kwh':f'{value:.10f}', 'average_proxy_kw':f'{value:.10f}',
               'annual_target_kwh':f'{annual:.6f}','hourly_weight':f'{weight:.8f}','annual_normalization_sum':f'{sums[key]:.8f}',
               'benchmark_source_ids':targets[key]['source_ids'],
               'profile_method':'NORMALIZED_EXISTING_SYNTHETIC_SCHEDULE_WEIGHT_NO_WEATHER',
               'data_origin':'LITERATURE_CALIBRATED_SYNTHETIC_PROXY_NOT_MEASURED_NOT_ENERGYPLUS',
               'is_measured':'false','is_energyplus_output':'false','has_hourly_weather':'false',
               'training_eligible':'false','independent_validation_eligible':'false','energy_sharing_eligible':'false',
               'calendar_convention':'2017_SYNTHETIC_LOCAL_STANDARD_NO_DST'})
    print(f'Regenerated {sum(counts.values())} hourly synthetic proxy rows -> {out}')
if __name__=='__main__':run()

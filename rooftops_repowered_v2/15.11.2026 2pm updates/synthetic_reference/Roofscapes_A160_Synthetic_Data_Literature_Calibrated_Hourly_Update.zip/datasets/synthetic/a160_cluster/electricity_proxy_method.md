# Literature-calibrated hourly electricity proxy (NOT simulation or observation)

This is an **illustrative hourly *electricity* series** for 4 buildings × 3 hypothetical cases, based on references R13–R19 in `source_register.csv`. It is designed to support UI prototyping, check potential unit magnitudes, and sanity-check subsequent independent EnergyPlus outputs. It is **not** a source of physics-simulated electricity demand, real A160 electricity meter records, or a valid training/validation label for the trained AI.

## Computation

For each building and low/base/high case, an annual kWh target is derived from directly cited electricity reference data (or explicit per-room/household transfer assumptions). The existing synthetic schedule fractions in `hourly_schedule_reference_2017.csv` are combined with **new author-chosen weights**. Hourly electricity is computed by normalizing weights over the full 8760-hour 2017 standard-time calendar and multiplying by the annual target. Thus every annual sum matches its documented annual target to numerical tolerance.

`E_(b,s,h) = AnnualBenchmark_(b,s) × [Standby_b + Σ(coeff_b,j × schedule_fraction_(b,s,h,j))] / Σ_(all 8760 h) [Standby_b + Σ(coeff_b,j × schedule_fraction_(b,s,h,j))]`.

The source research supports **annual electricity totals or intensities**, not these hourly profiles. The profile weighting is a sensitivity design inspired by known schedule-driven end uses, **not calibrated measured hourly shape, not weather-conditioned, not EnergyPlus output**.

## Annual targets and caveats

- **A160 office:** low from VOPI4 2024 actual office electricity 74.68 MWh / 942 m² ≈ 79.28 kWh_e/m²/year; base from its 2022 108.39 MWh / 942 m² ≈ 115.06; high uses 165 kWh_e/m²/year as a selected point inside a research review's 160–170 range for fully electric offices in a different context. Multiply by the package's **assumed** scenario conditioned areas. VOPI4 is not A160 and may use different HVAC energy carriers. R13/R14.
- **ITAEB vocational audiovisual school:** low/base/high annual electric-only intensities 19.54, 40.69, 50.84 kWh_e/m²/year from four primary-school electricity comparisons in an ICAEN example audit. School type and electrification do not match ITAEB directly. Multiply by assumed ITAEB conditioned areas. R15.
- **Ciutat de Granada 95–97:** IDAE 2025 household-size categories 1,943 (one-person), 2,765 (two–three), 3,253 (>3) kWh_e/household/year for **nonthermal electricity**. Combine 10 one-bedroom + 8 two-bedroom apartments with explicitly HYPOTHETICAL occupant counts for low/base/high. Excludes heat-pump heating/DHW and shared services. R16 and original site's source for dwelling sizes.
- **NH Poblenou hotel:** Barcelona H10 Madison baseline 879,579 and post-intervention 628,718 kWh_e/year divided by 101 published H10 rooms and multiplied by NH's 129 rooms. Low applies a completely hypothetical 0.8 factor to H10 post value; base uses post; high uses baseline. An energy-systems intervention in another property is not a statistical range or evidence about NH. R17/R18 plus original NH site fact.

## Critical restrictions

1. Files live **only** in `datasets/synthetic/a160_cluster/`, never replace `datasets/processed/demand_hourly.csv`, verified A160 demand, `pipeline/models/`, or trained model results.
2. `data_origin=LITERATURE_CALIBRATED_SYNTHETIC_PROXY_NOT_MEASURED_NOT_ENERGYPLUS`; `energy_sharing_eligible=false`, `training_eligible=false`, `independent_validation_eligible=false`.
3. The 2017 synthetic local-standard-no-DST timestamps have NO associated weather sequence, despite also displaying year 2017. Do not silently join to PVGIS SARAH3 2017 or EnergyPlus IWEC.
4. A model taught to copy annual-profile-scaled schedule weights is learning our **assumed formula**, not useful physical behavior. Use these values only as a sanity check and UI fixture, not ML training target.
5. Annual figures are not the measured electricity consumption of any site in the selected cluster. Do not create financial/environmental savings from these series as though they were actual.
6. Future physics training must consume *independent* EnergyPlus `Electricity:Facility` hourly outputs from validated geometry/weather/HVAC and disjoint train/validation/test configurations.

For exact source URLs see `electricity_benchmarks.csv` and `source_register.csv`. Run `python scripts/generate_literature_electricity_proxy.py` if you edit the original 2017 schedules, source values, or annual benchmarking assumptions.

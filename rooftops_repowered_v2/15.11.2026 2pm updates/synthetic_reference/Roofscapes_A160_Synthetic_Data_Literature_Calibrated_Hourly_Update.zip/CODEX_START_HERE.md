# Codex start here — A160 site-specific EnergyPlus, then AI

Repository: https://github.com/SindhujaDavuluri/rooftops_repowered_v2  
Reference `main` SHA at handover: `de3ea0ca5f2c022af5f4d50d054a0c897e5eb914`

**TASK**

Use all files in this ZIP, especially `docs/CODEX_STAGED_HANDOVER.md` and the CSV/JSON files under `datasets/synthetic/a160_cluster/`.

1. Create a new work branch and audit current code/test state. Never overwrite previously trained models, rooftop results or validated reports.
2. Validate the supplied synthetic input schema and provenance. The CSV/JSON files are **research assumptions and published site facts**, NOT hourly consumption data. Do not blend the two.
3. Verify whether **Rhino 8 + Grasshopper Ladybug Tools 1.10/Honeybee** are installed and usable. Retrieve the **2026 Barcelona 3D DWG for el Parc i la Llacuna del Poblenou** from the official municipal portal; if portal requires manual interaction or Rhino is absent, record exact blocker and build the most defensible alternative geometrical EnergyPlus skeleton without inventing an as-built model. Keep a conversion QA report. Import A160 by cadastral ID `2635601DF3823F`, check its modern completed footprint/volumes/levels and build real energy thermal zones.
4. First complete **A160-specific annual EnergyPlus electricity simulations** with documented geometry, envelope, HVAC, schedules and weather; validate end-use units and complete reference-year hourly meters. Preserve previous 511m² US office experiment unmodified.
5. **Only after the EnergyPlus simulation quality gate passes, automatically continue to train and validate a separately versioned A160 XGBoost surrogate**, with whole-configuration train/validation/test splits and hour-of-week plus schedule-aware linear baseline comparisons. No real-meter accuracy claim. If validation fails, keep a baseline and publish the failure.
6. Prepare but do not overclaim later school/residential/hotel simulation expansion, and do not put any hypothetical PVGIS series in the verified case-study sharing route.
7. Run tests and preservation checks and prepare a PR with clear results, blockers, exact run commands and source URLs.

**Required explicit gates:** published building facts != synthetic assumptions; office meter target = EnergyPlus `Electricity:Facility` J / 3,600,000; PVGIS 2017 SARAH3 != IWEC typical-year weather; site installed PV kWp unknown; A160 surrogate can't infer other typologies without validation.

**Primary references**: https://portaldades.ajuntament.barcelona.cat/mapes/146 ; https://discourse.ladybug.tools/t/ladybug-tools-for-grasshopper-1-10-0-release/40026 ; https://docs.ladybug.tools/hb-energy-primer/components/5_simulate/model_to_osm ; https://www.energycodes.gov/prototype-building-models ; https://www.conrentramway.com/portfolio/a160/ .


### Literature proxy addition

Review `datasets/synthetic/a160_cluster/electricity_proxy_method.md`; run `python tests/test_literature_electricity_proxy.py`. The hourly electricity proxies are UI/sanity fixtures only, NOT EnergyPlus output and NOT ML training/validation targets. Preserve gating.
